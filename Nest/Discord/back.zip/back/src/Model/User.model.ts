export interface User {
	_id: string; // Identifiant du canal
	username: string; // Nom d'utilisateur
	email: string; // Email de l'utilisateur (facultatif)
	password: string; // Mot de passe de l'utilisateur
  };
